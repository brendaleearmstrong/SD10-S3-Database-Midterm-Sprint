-- Query #1 - Select All for All Tables
-- Select statements for all tables to check for valid dataset imports

select * from brands;
select * from certifications;
select * from employee_certifications;
select * from equipment;
select * from equipment_maintenance;
select * from fitness_class;
select * from gym_location;
select * from inventory_log;
select * from membership;
select * from membership_type;
select * from person_information;
select * from price;
select * from province;
select * from receipt; 
select * from receipt_item; 
select * from salary;
select * from services;
select * from staff;
select * from staff_address;
select * from supplements;
select * from tax;



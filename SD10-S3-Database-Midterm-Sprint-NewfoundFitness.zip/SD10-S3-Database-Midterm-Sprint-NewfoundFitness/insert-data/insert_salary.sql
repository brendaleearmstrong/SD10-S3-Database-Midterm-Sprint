-- Salary table (expanding to 10 records)
INSERT INTO Salary (Salary_Amount) VALUES
(30000.00), (35000.00), (40000.00), (45000.00), (50000.00),
(55000.00), (60000.00), (65000.00), (70000.00), (75000.00);
-- Tax (only for Newfoundland)
INSERT INTO Tax (Tax_Name, Tax_Rate, Is_Active, Effective_Date, Description) VALUES
('HST', 15.00, TRUE, '2023-01-01', 'Harmonized Sales Tax for Newfoundland and Labrador')

select * from Tax;
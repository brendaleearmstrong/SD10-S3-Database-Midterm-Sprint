INSERT INTO Province (Province_Name, Province_Code) VALUES
('Newfoundland and Labrador', 'NL'),
('Prince Edward Island', 'PE'),
('Nova Scotia', 'NS'),
('New Brunswick', 'NB'),
('Quebec', 'QC'),
('Ontario', 'ON'),
('Manitoba', 'MB'),
('Saskatchewan', 'SK'),
('Alberta', 'AB'),
('British Columbia', 'BC'),
('Yukon', 'YT'),
('Northwest Territories', 'NT'),
('Nunavut', 'NU');

select * from Province;
INSERT INTO Equipment_Maintenance (Equipment_ID, Maintenance_Date, Description, staff_id) VALUES
(1, '2023-05-15', 'Regular treadmill maintenance',741),
(5, '2023-05-20', 'Elliptical squeaking issue fixed', 742),
(20, '2023-05-25', 'Weight stack pin replacement', 743),
(8, '2023-05-30', 'Bike seat adjustment', 744),
(9, '2023-06-05','Seat on Rowing Maching lubrication', 745);
-- Add more as needed

select * from equipment_maintenance;

select * from staff;
INSERT INTO Gym_Location (Address_ID) VALUES
(548),
(549),
(550),
(551),
(552);

select * from gym_location;
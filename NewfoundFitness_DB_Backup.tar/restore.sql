--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "NewfoundFitness_DB";
--
-- Name: NewfoundFitness_DB; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "NewfoundFitness_DB" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE "NewfoundFitness_DB" OWNER TO postgres;

\connect "NewfoundFitness_DB"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: get_membership_report(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_membership_report(p_membership_type_id integer DEFAULT NULL::integer) RETURNS TABLE(membership_type_name character varying, member_count bigint, avg_membership_length numeric, total_revenue numeric, percentage_of_total numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    WITH MembershipStats AS (
        SELECT
            mt.Membership_Type_ID,
            mt.Type_Name,
            COUNT(m.Member_ID) AS member_count,
            AVG(m.Membership_Length) AS avg_membership_length,
            SUM(p.Price_Amount * m.Membership_Length) AS membership_revenue
        FROM
            Membership_Type mt
        LEFT JOIN
            Membership m ON mt.Membership_Type_ID = m.Membership_Type_ID
        LEFT JOIN
            Price p ON m.Price_ID = p.Price_ID
        WHERE
            p_membership_type_id IS NULL OR mt.Membership_Type_ID = p_membership_type_id
        GROUP BY
            mt.Membership_Type_ID, mt.Type_Name
    ),
    TotalRevenue AS (
        SELECT SUM(membership_revenue) AS grand_total FROM MembershipStats
    )
    SELECT
        ms.Type_Name,
        ms.member_count,
        ROUND(ms.avg_membership_length, 2) AS avg_membership_length,
        ms.membership_revenue,
        ROUND(ms.membership_revenue / NULLIF(tr.grand_total, 0) * 100, 2) AS percentage_of_total
    FROM
        MembershipStats ms,
        TotalRevenue tr
    ORDER BY
        ms.membership_revenue DESC;
END;
$$;


ALTER FUNCTION public.get_membership_report(p_membership_type_id integer) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.address (
    address_id integer NOT NULL,
    street_name character varying(100) NOT NULL,
    street_number character varying(20) NOT NULL,
    city character varying(50) NOT NULL,
    province_id integer NOT NULL,
    postal_code character varying(20) NOT NULL
);


ALTER TABLE public.address OWNER TO postgres;

--
-- Name: address_address_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.address_address_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.address_address_id_seq OWNER TO postgres;

--
-- Name: address_address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.address_address_id_seq OWNED BY public.address.address_id;


--
-- Name: brands; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.brands (
    brand_id integer NOT NULL,
    brand_name character varying(100) NOT NULL,
    brand_description text
);


ALTER TABLE public.brands OWNER TO postgres;

--
-- Name: brands_brand_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.brands_brand_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.brands_brand_id_seq OWNER TO postgres;

--
-- Name: brands_brand_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.brands_brand_id_seq OWNED BY public.brands.brand_id;


--
-- Name: certifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.certifications (
    certification_id integer NOT NULL,
    certification_name character varying(100) NOT NULL,
    certification_description text,
    issuing_organization character varying(100) NOT NULL,
    certification_level character varying(50),
    CONSTRAINT certifications_certification_level_check CHECK (((certification_level)::text = ANY ((ARRAY['Certificate'::character varying, 'Degree'::character varying, 'Masters Degree'::character varying, 'Micro-credential'::character varying, 'Certification'::character varying])::text[])))
);


ALTER TABLE public.certifications OWNER TO postgres;

--
-- Name: certifications_certification_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.certifications_certification_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.certifications_certification_id_seq OWNER TO postgres;

--
-- Name: certifications_certification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.certifications_certification_id_seq OWNED BY public.certifications.certification_id;


--
-- Name: class_attendance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.class_attendance (
    attendance_id integer NOT NULL,
    class_id integer NOT NULL,
    person_id integer NOT NULL,
    attendance_date date
);


ALTER TABLE public.class_attendance OWNER TO postgres;

--
-- Name: class_attendance_attendance_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.class_attendance_attendance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.class_attendance_attendance_id_seq OWNER TO postgres;

--
-- Name: class_attendance_attendance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.class_attendance_attendance_id_seq OWNED BY public.class_attendance.attendance_id;


--
-- Name: employee_certifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_certifications (
    employee_certification_id integer NOT NULL,
    staff_id integer NOT NULL,
    certification_id integer NOT NULL,
    date_obtained date NOT NULL,
    expiration_date date,
    certificate_number character varying(50)
);


ALTER TABLE public.employee_certifications OWNER TO postgres;

--
-- Name: employee_certifications_employee_certification_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employee_certifications_employee_certification_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.employee_certifications_employee_certification_id_seq OWNER TO postgres;

--
-- Name: employee_certifications_employee_certification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.employee_certifications_employee_certification_id_seq OWNED BY public.employee_certifications.employee_certification_id;


--
-- Name: equipment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.equipment (
    equipment_id integer NOT NULL,
    equipment_name character varying(100) NOT NULL,
    purchase_date date NOT NULL,
    availability_status character varying(20) NOT NULL,
    CONSTRAINT equipment_availability_status_check CHECK (((availability_status)::text = ANY ((ARRAY['Available'::character varying, 'In Use'::character varying, 'Maintenance'::character varying, 'Out of Order'::character varying])::text[])))
);


ALTER TABLE public.equipment OWNER TO postgres;

--
-- Name: equipment_equipment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.equipment_equipment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.equipment_equipment_id_seq OWNER TO postgres;

--
-- Name: equipment_equipment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.equipment_equipment_id_seq OWNED BY public.equipment.equipment_id;


--
-- Name: equipment_maintenance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.equipment_maintenance (
    maintenance_id integer NOT NULL,
    equipment_id integer NOT NULL,
    maintenance_date date NOT NULL,
    description text,
    staff_id integer
);


ALTER TABLE public.equipment_maintenance OWNER TO postgres;

--
-- Name: equipment_maintenance_maintenance_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.equipment_maintenance_maintenance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.equipment_maintenance_maintenance_id_seq OWNER TO postgres;

--
-- Name: equipment_maintenance_maintenance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.equipment_maintenance_maintenance_id_seq OWNED BY public.equipment_maintenance.maintenance_id;


--
-- Name: fitness_class; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fitness_class (
    class_id integer NOT NULL,
    staff_id integer NOT NULL,
    price_id integer NOT NULL,
    maximum_capacity integer NOT NULL,
    class_name character varying(100) NOT NULL,
    description text,
    duration integer NOT NULL,
    CONSTRAINT fitness_class_duration_check CHECK ((duration > 0)),
    CONSTRAINT fitness_class_maximum_capacity_check CHECK ((maximum_capacity > 0))
);


ALTER TABLE public.fitness_class OWNER TO postgres;

--
-- Name: fitness_class_class_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.fitness_class_class_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.fitness_class_class_id_seq OWNER TO postgres;

--
-- Name: fitness_class_class_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.fitness_class_class_id_seq OWNED BY public.fitness_class.class_id;


--
-- Name: gym_location; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gym_location (
    gym_id integer NOT NULL,
    address_id integer NOT NULL
);


ALTER TABLE public.gym_location OWNER TO postgres;

--
-- Name: gym_location_gym_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gym_location_gym_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.gym_location_gym_id_seq OWNER TO postgres;

--
-- Name: gym_location_gym_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.gym_location_gym_id_seq OWNED BY public.gym_location.gym_id;


--
-- Name: inventory_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventory_log (
    log_id integer NOT NULL,
    supplement_id integer NOT NULL,
    change_amount integer NOT NULL,
    new_stock_amount integer NOT NULL,
    log_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    staff_id integer,
    log_type character varying(20),
    notes text,
    CONSTRAINT inventory_log_log_type_check CHECK (((log_type)::text = ANY ((ARRAY['Restock'::character varying, 'Sale'::character varying, 'Adjustment'::character varying, 'Expired'::character varying])::text[])))
);


ALTER TABLE public.inventory_log OWNER TO postgres;

--
-- Name: inventory_log_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inventory_log_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inventory_log_log_id_seq OWNER TO postgres;

--
-- Name: inventory_log_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inventory_log_log_id_seq OWNED BY public.inventory_log.log_id;


--
-- Name: membership; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.membership (
    member_id integer NOT NULL,
    person_id integer NOT NULL,
    address_id integer NOT NULL,
    price_id integer NOT NULL,
    membership_type_id integer NOT NULL,
    membership_length integer NOT NULL,
    date_joined date NOT NULL,
    expiration_date date NOT NULL
);


ALTER TABLE public.membership OWNER TO postgres;

--
-- Name: membership_member_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.membership_member_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.membership_member_id_seq OWNER TO postgres;

--
-- Name: membership_member_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.membership_member_id_seq OWNED BY public.membership.member_id;


--
-- Name: membership_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.membership_type (
    membership_type_id integer NOT NULL,
    type_name character varying(50) NOT NULL,
    description text
);


ALTER TABLE public.membership_type OWNER TO postgres;

--
-- Name: membership_type_membership_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.membership_type_membership_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.membership_type_membership_type_id_seq OWNER TO postgres;

--
-- Name: membership_type_membership_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.membership_type_membership_type_id_seq OWNED BY public.membership_type.membership_type_id;


--
-- Name: person_information; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.person_information (
    person_id integer NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    email character varying(100) NOT NULL,
    phone_number character varying(20),
    date_of_birth date
);


ALTER TABLE public.person_information OWNER TO postgres;

--
-- Name: person_information_person_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.person_information_person_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.person_information_person_id_seq OWNER TO postgres;

--
-- Name: person_information_person_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.person_information_person_id_seq OWNED BY public.person_information.person_id;


--
-- Name: price; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.price (
    price_id integer NOT NULL,
    price_amount numeric(10,2) NOT NULL,
    CONSTRAINT price_price_amount_check CHECK ((price_amount >= (0)::numeric))
);


ALTER TABLE public.price OWNER TO postgres;

--
-- Name: price_price_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.price_price_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.price_price_id_seq OWNER TO postgres;

--
-- Name: price_price_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.price_price_id_seq OWNED BY public.price.price_id;


--
-- Name: province; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.province (
    province_id integer NOT NULL,
    province_name character varying(50) NOT NULL,
    province_code character(2) NOT NULL
);


ALTER TABLE public.province OWNER TO postgres;

--
-- Name: province_province_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.province_province_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.province_province_id_seq OWNER TO postgres;

--
-- Name: province_province_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.province_province_id_seq OWNED BY public.province.province_id;


--
-- Name: receipt; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.receipt (
    receipt_id integer NOT NULL,
    member_id integer NOT NULL,
    payment_method character varying(50) NOT NULL,
    tax_id integer NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    tax_amount numeric(10,2) NOT NULL,
    total_amount numeric(10,2) NOT NULL,
    receipt_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT receipt_subtotal_check CHECK ((subtotal >= (0)::numeric)),
    CONSTRAINT receipt_tax_amount_check CHECK ((tax_amount >= (0)::numeric)),
    CONSTRAINT receipt_total_amount_check CHECK ((total_amount >= (0)::numeric))
);


ALTER TABLE public.receipt OWNER TO postgres;

--
-- Name: receipt_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.receipt_item (
    receipt_item_id integer NOT NULL,
    receipt_id integer NOT NULL,
    supplement_id integer,
    fitness_class_id integer,
    service_id integer,
    quantity integer NOT NULL,
    price_id integer NOT NULL,
    item_subtotal numeric(10,2) NOT NULL,
    item_tax_amount numeric(10,2) NOT NULL,
    item_total numeric(10,2) NOT NULL,
    CONSTRAINT receipt_item_check CHECK ((((supplement_id IS NOT NULL) AND (fitness_class_id IS NULL) AND (service_id IS NULL)) OR ((supplement_id IS NULL) AND (fitness_class_id IS NOT NULL) AND (service_id IS NULL)) OR ((supplement_id IS NULL) AND (fitness_class_id IS NULL) AND (service_id IS NOT NULL)))),
    CONSTRAINT receipt_item_item_subtotal_check CHECK ((item_subtotal >= (0)::numeric)),
    CONSTRAINT receipt_item_item_tax_amount_check CHECK ((item_tax_amount >= (0)::numeric)),
    CONSTRAINT receipt_item_item_total_check CHECK ((item_total >= (0)::numeric)),
    CONSTRAINT receipt_item_quantity_check CHECK ((quantity > 0))
);


ALTER TABLE public.receipt_item OWNER TO postgres;

--
-- Name: receipt_item_receipt_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.receipt_item_receipt_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.receipt_item_receipt_item_id_seq OWNER TO postgres;

--
-- Name: receipt_item_receipt_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.receipt_item_receipt_item_id_seq OWNED BY public.receipt_item.receipt_item_id;


--
-- Name: receipt_receipt_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.receipt_receipt_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.receipt_receipt_id_seq OWNER TO postgres;

--
-- Name: receipt_receipt_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.receipt_receipt_id_seq OWNED BY public.receipt.receipt_id;


--
-- Name: salary; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.salary (
    salary_id integer NOT NULL,
    salary_amount numeric(10,2) NOT NULL,
    CONSTRAINT salary_salary_amount_check CHECK ((salary_amount >= (0)::numeric))
);


ALTER TABLE public.salary OWNER TO postgres;

--
-- Name: salary_salary_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.salary_salary_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.salary_salary_id_seq OWNER TO postgres;

--
-- Name: salary_salary_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.salary_salary_id_seq OWNED BY public.salary.salary_id;


--
-- Name: services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.services (
    service_id integer NOT NULL,
    service_name character varying(100) NOT NULL,
    description text,
    duration integer,
    price_id integer NOT NULL,
    is_taxable boolean DEFAULT true
);


ALTER TABLE public.services OWNER TO postgres;

--
-- Name: services_service_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.services_service_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.services_service_id_seq OWNER TO postgres;

--
-- Name: services_service_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.services_service_id_seq OWNED BY public.services.service_id;


--
-- Name: staff; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.staff (
    staff_id integer NOT NULL,
    person_id integer NOT NULL,
    staff_address_id integer NOT NULL,
    salary_id integer NOT NULL,
    "position" character varying(100)
);


ALTER TABLE public.staff OWNER TO postgres;

--
-- Name: staff_address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.staff_address (
    staff_address_id integer NOT NULL,
    street_name character varying(100) NOT NULL,
    street_number character varying(20) NOT NULL,
    city character varying(50) NOT NULL,
    province_id integer NOT NULL,
    postal_code character varying(20) NOT NULL
);


ALTER TABLE public.staff_address OWNER TO postgres;

--
-- Name: staff_address_staff_address_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.staff_address_staff_address_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.staff_address_staff_address_id_seq OWNER TO postgres;

--
-- Name: staff_address_staff_address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.staff_address_staff_address_id_seq OWNED BY public.staff_address.staff_address_id;


--
-- Name: staff_staff_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.staff_staff_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.staff_staff_id_seq OWNER TO postgres;

--
-- Name: staff_staff_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.staff_staff_id_seq OWNED BY public.staff.staff_id;


--
-- Name: supplements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.supplements (
    supplement_id integer NOT NULL,
    brand_id integer NOT NULL,
    price_id integer NOT NULL,
    supplement_name character varying(100) NOT NULL,
    stock_amount integer NOT NULL,
    reorder_number integer NOT NULL,
    min_stock_level integer DEFAULT 0 NOT NULL,
    max_stock_level integer DEFAULT 100 NOT NULL,
    CONSTRAINT check_stock_levels CHECK ((min_stock_level < max_stock_level)),
    CONSTRAINT supplements_reorder_number_check CHECK ((reorder_number > 0)),
    CONSTRAINT supplements_stock_amount_check CHECK ((stock_amount >= 0))
);


ALTER TABLE public.supplements OWNER TO postgres;

--
-- Name: supplements_supplement_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.supplements_supplement_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.supplements_supplement_id_seq OWNER TO postgres;

--
-- Name: supplements_supplement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.supplements_supplement_id_seq OWNED BY public.supplements.supplement_id;


--
-- Name: tax; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tax (
    tax_id integer NOT NULL,
    tax_name character varying(50) NOT NULL,
    tax_rate numeric(5,2) NOT NULL,
    is_active boolean DEFAULT true,
    effective_date date NOT NULL,
    description text,
    CONSTRAINT tax_tax_rate_check CHECK (((tax_rate >= (0)::numeric) AND (tax_rate <= (100)::numeric)))
);


ALTER TABLE public.tax OWNER TO postgres;

--
-- Name: tax_tax_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tax_tax_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tax_tax_id_seq OWNER TO postgres;

--
-- Name: tax_tax_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tax_tax_id_seq OWNED BY public.tax.tax_id;


--
-- Name: vw_class_attendance_summary; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_class_attendance_summary AS
 SELECT fc.class_id,
    fc.class_name,
    pi.person_id,
    date_part('year'::text, age((pi.date_of_birth)::timestamp with time zone)) AS age
   FROM ((public.fitness_class fc
     JOIN public.class_attendance ca ON ((fc.class_id = ca.class_id)))
     JOIN public.person_information pi ON ((ca.person_id = pi.person_id)));


ALTER VIEW public.vw_class_attendance_summary OWNER TO postgres;

--
-- Name: vw_equipment_status; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_equipment_status AS
 SELECT e.equipment_id,
    e.equipment_name,
    e.purchase_date,
    e.availability_status,
    COALESCE(max(em.maintenance_date), e.purchase_date) AS last_maintenance_date,
    (COALESCE(max(em.maintenance_date), e.purchase_date) + '90 days'::interval) AS next_scheduled_maintenance
   FROM (public.equipment e
     LEFT JOIN public.equipment_maintenance em ON ((e.equipment_id = em.equipment_id)))
  GROUP BY e.equipment_id, e.equipment_name, e.purchase_date, e.availability_status;


ALTER VIEW public.vw_equipment_status OWNER TO postgres;

--
-- Name: vw_member_activity; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_member_activity AS
 SELECT m.member_id,
    (((pi.first_name)::text || ' '::text) || (pi.last_name)::text) AS member_name,
    count(DISTINCT r.receipt_id) AS total_purchases,
    sum(r.total_amount) AS total_spent,
    count(DISTINCT
        CASE
            WHEN (ri.fitness_class_id IS NOT NULL) THEN ri.fitness_class_id
            ELSE NULL::integer
        END) AS classes_attended,
    count(DISTINCT
        CASE
            WHEN (ri.service_id IS NOT NULL) THEN ri.service_id
            ELSE NULL::integer
        END) AS services_used,
    count(DISTINCT
        CASE
            WHEN (ri.supplement_id IS NOT NULL) THEN ri.supplement_id
            ELSE NULL::integer
        END) AS supplements_purchased
   FROM (((public.membership m
     JOIN public.person_information pi ON ((m.person_id = pi.person_id)))
     LEFT JOIN public.receipt r ON ((m.member_id = r.member_id)))
     LEFT JOIN public.receipt_item ri ON ((r.receipt_id = ri.receipt_id)))
  GROUP BY m.member_id, pi.first_name, pi.last_name;


ALTER VIEW public.vw_member_activity OWNER TO postgres;

--
-- Name: vw_member_overview; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_member_overview AS
 SELECT m.member_id,
    pi.first_name,
    pi.last_name,
    pi.email,
    mt.type_name AS membership_type,
    m.date_joined,
    m.expiration_date,
    a.city,
    p.province_name
   FROM ((((public.membership m
     JOIN public.person_information pi ON ((m.person_id = pi.person_id)))
     JOIN public.membership_type mt ON ((m.membership_type_id = mt.membership_type_id)))
     JOIN public.address a ON ((m.address_id = a.address_id)))
     JOIN public.province p ON ((a.province_id = p.province_id)));


ALTER VIEW public.vw_member_overview OWNER TO postgres;

--
-- Name: vw_sales_summary; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_sales_summary AS
 SELECT date_trunc('day'::text, r.receipt_date) AS sale_date,
    count(DISTINCT r.receipt_id) AS total_transactions,
    sum(r.total_amount) AS total_revenue,
    sum(
        CASE
            WHEN (ri.supplement_id IS NOT NULL) THEN ri.item_total
            ELSE (0)::numeric
        END) AS supplement_revenue,
    sum(
        CASE
            WHEN (ri.fitness_class_id IS NOT NULL) THEN ri.item_total
            ELSE (0)::numeric
        END) AS class_revenue,
    sum(
        CASE
            WHEN (ri.service_id IS NOT NULL) THEN ri.item_total
            ELSE (0)::numeric
        END) AS service_revenue
   FROM (public.receipt r
     JOIN public.receipt_item ri ON ((r.receipt_id = ri.receipt_id)))
  GROUP BY (date_trunc('day'::text, r.receipt_date));


ALTER VIEW public.vw_sales_summary OWNER TO postgres;

--
-- Name: vw_staff_details; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_staff_details AS
 SELECT s.staff_id,
    pi.first_name,
    pi.last_name,
    pi.email,
    a.city,
    p.province_name,
    sa.salary_amount,
    count(DISTINCT ec.certification_id) AS certification_count
   FROM (((((public.staff s
     JOIN public.person_information pi ON ((s.person_id = pi.person_id)))
     JOIN public.salary sa ON ((s.salary_id = sa.salary_id)))
     LEFT JOIN public.employee_certifications ec ON ((s.staff_id = ec.staff_id)))
     JOIN public.staff_address a ON ((s.staff_address_id = a.staff_address_id)))
     JOIN public.province p ON ((a.province_id = p.province_id)))
  GROUP BY s.staff_id, pi.first_name, pi.last_name, pi.email, a.city, p.province_name, sa.salary_amount;


ALTER VIEW public.vw_staff_details OWNER TO postgres;

--
-- Name: vw_staff_performance; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_staff_performance AS
 SELECT s.staff_id,
    (((pi.first_name)::text || ' '::text) || (pi.last_name)::text) AS staff_name,
    count(DISTINCT fc.class_id) AS classes_taught,
    sum(ri.quantity) AS total_class_attendees,
    sum(
        CASE
            WHEN (ri.fitness_class_id IS NOT NULL) THEN ri.item_total
            ELSE (0)::numeric
        END) AS class_revenue,
    count(DISTINCT ec.certification_id) AS certifications
   FROM ((((public.staff s
     JOIN public.person_information pi ON ((s.person_id = pi.person_id)))
     LEFT JOIN public.fitness_class fc ON ((s.staff_id = fc.staff_id)))
     LEFT JOIN public.receipt_item ri ON ((fc.class_id = ri.fitness_class_id)))
     LEFT JOIN public.employee_certifications ec ON ((s.staff_id = ec.staff_id)))
  GROUP BY s.staff_id, pi.first_name, pi.last_name;


ALTER VIEW public.vw_staff_performance OWNER TO postgres;

--
-- Name: vw_supplement_inventory; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_supplement_inventory AS
 SELECT s.supplement_id,
    s.supplement_name,
    b.brand_name,
    s.stock_amount,
    s.reorder_number,
    s.min_stock_level,
    s.max_stock_level,
    p.price_amount AS current_price
   FROM ((public.supplements s
     JOIN public.brands b ON ((s.brand_id = b.brand_id)))
     JOIN public.price p ON ((s.price_id = p.price_id)));


ALTER VIEW public.vw_supplement_inventory OWNER TO postgres;

--
-- Name: address address_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address ALTER COLUMN address_id SET DEFAULT nextval('public.address_address_id_seq'::regclass);


--
-- Name: brands brand_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.brands ALTER COLUMN brand_id SET DEFAULT nextval('public.brands_brand_id_seq'::regclass);


--
-- Name: certifications certification_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certifications ALTER COLUMN certification_id SET DEFAULT nextval('public.certifications_certification_id_seq'::regclass);


--
-- Name: class_attendance attendance_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class_attendance ALTER COLUMN attendance_id SET DEFAULT nextval('public.class_attendance_attendance_id_seq'::regclass);


--
-- Name: employee_certifications employee_certification_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_certifications ALTER COLUMN employee_certification_id SET DEFAULT nextval('public.employee_certifications_employee_certification_id_seq'::regclass);


--
-- Name: equipment equipment_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipment ALTER COLUMN equipment_id SET DEFAULT nextval('public.equipment_equipment_id_seq'::regclass);


--
-- Name: equipment_maintenance maintenance_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipment_maintenance ALTER COLUMN maintenance_id SET DEFAULT nextval('public.equipment_maintenance_maintenance_id_seq'::regclass);


--
-- Name: fitness_class class_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fitness_class ALTER COLUMN class_id SET DEFAULT nextval('public.fitness_class_class_id_seq'::regclass);


--
-- Name: gym_location gym_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gym_location ALTER COLUMN gym_id SET DEFAULT nextval('public.gym_location_gym_id_seq'::regclass);


--
-- Name: inventory_log log_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_log ALTER COLUMN log_id SET DEFAULT nextval('public.inventory_log_log_id_seq'::regclass);


--
-- Name: membership member_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.membership ALTER COLUMN member_id SET DEFAULT nextval('public.membership_member_id_seq'::regclass);


--
-- Name: membership_type membership_type_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.membership_type ALTER COLUMN membership_type_id SET DEFAULT nextval('public.membership_type_membership_type_id_seq'::regclass);


--
-- Name: person_information person_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.person_information ALTER COLUMN person_id SET DEFAULT nextval('public.person_information_person_id_seq'::regclass);


--
-- Name: price price_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.price ALTER COLUMN price_id SET DEFAULT nextval('public.price_price_id_seq'::regclass);


--
-- Name: province province_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.province ALTER COLUMN province_id SET DEFAULT nextval('public.province_province_id_seq'::regclass);


--
-- Name: receipt receipt_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.receipt ALTER COLUMN receipt_id SET DEFAULT nextval('public.receipt_receipt_id_seq'::regclass);


--
-- Name: receipt_item receipt_item_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.receipt_item ALTER COLUMN receipt_item_id SET DEFAULT nextval('public.receipt_item_receipt_item_id_seq'::regclass);


--
-- Name: salary salary_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salary ALTER COLUMN salary_id SET DEFAULT nextval('public.salary_salary_id_seq'::regclass);


--
-- Name: services service_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services ALTER COLUMN service_id SET DEFAULT nextval('public.services_service_id_seq'::regclass);


--
-- Name: staff staff_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff ALTER COLUMN staff_id SET DEFAULT nextval('public.staff_staff_id_seq'::regclass);


--
-- Name: staff_address staff_address_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff_address ALTER COLUMN staff_address_id SET DEFAULT nextval('public.staff_address_staff_address_id_seq'::regclass);


--
-- Name: supplements supplement_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplements ALTER COLUMN supplement_id SET DEFAULT nextval('public.supplements_supplement_id_seq'::regclass);


--
-- Name: tax tax_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tax ALTER COLUMN tax_id SET DEFAULT nextval('public.tax_tax_id_seq'::regclass);


--
-- Data for Name: address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.address (address_id, street_name, street_number, city, province_id, postal_code) FROM stdin;
\.
COPY public.address (address_id, street_name, street_number, city, province_id, postal_code) FROM '$$PATH$$/3915.dat';

--
-- Data for Name: brands; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.brands (brand_id, brand_name, brand_description) FROM stdin;
\.
COPY public.brands (brand_id, brand_name, brand_description) FROM '$$PATH$$/3941.dat';

--
-- Data for Name: certifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.certifications (certification_id, certification_name, certification_description, issuing_organization, certification_level) FROM stdin;
\.
COPY public.certifications (certification_id, certification_name, certification_description, issuing_organization, certification_level) FROM '$$PATH$$/3945.dat';

--
-- Data for Name: class_attendance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.class_attendance (attendance_id, class_id, person_id, attendance_date) FROM stdin;
\.
COPY public.class_attendance (attendance_id, class_id, person_id, attendance_date) FROM '$$PATH$$/3955.dat';

--
-- Data for Name: employee_certifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_certifications (employee_certification_id, staff_id, certification_id, date_obtained, expiration_date, certificate_number) FROM stdin;
\.
COPY public.employee_certifications (employee_certification_id, staff_id, certification_id, date_obtained, expiration_date, certificate_number) FROM '$$PATH$$/3947.dat';

--
-- Data for Name: equipment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.equipment (equipment_id, equipment_name, purchase_date, availability_status) FROM stdin;
\.
COPY public.equipment (equipment_id, equipment_name, purchase_date, availability_status) FROM '$$PATH$$/3925.dat';

--
-- Data for Name: equipment_maintenance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.equipment_maintenance (maintenance_id, equipment_id, maintenance_date, description, staff_id) FROM stdin;
\.
COPY public.equipment_maintenance (maintenance_id, equipment_id, maintenance_date, description, staff_id) FROM '$$PATH$$/3937.dat';

--
-- Data for Name: fitness_class; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fitness_class (class_id, staff_id, price_id, maximum_capacity, class_name, description, duration) FROM stdin;
\.
COPY public.fitness_class (class_id, staff_id, price_id, maximum_capacity, class_name, description, duration) FROM '$$PATH$$/3939.dat';

--
-- Data for Name: gym_location; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gym_location (gym_id, address_id) FROM stdin;
\.
COPY public.gym_location (gym_id, address_id) FROM '$$PATH$$/3929.dat';

--
-- Data for Name: inventory_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventory_log (log_id, supplement_id, change_amount, new_stock_amount, log_date, staff_id, log_type, notes) FROM stdin;
\.
COPY public.inventory_log (log_id, supplement_id, change_amount, new_stock_amount, log_date, staff_id, log_type, notes) FROM '$$PATH$$/3949.dat';

--
-- Data for Name: membership; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.membership (member_id, person_id, address_id, price_id, membership_type_id, membership_length, date_joined, expiration_date) FROM stdin;
\.
COPY public.membership (member_id, person_id, address_id, price_id, membership_type_id, membership_length, date_joined, expiration_date) FROM '$$PATH$$/3923.dat';

--
-- Data for Name: membership_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.membership_type (membership_type_id, type_name, description) FROM stdin;
\.
COPY public.membership_type (membership_type_id, type_name, description) FROM '$$PATH$$/3921.dat';

--
-- Data for Name: person_information; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.person_information (person_id, first_name, last_name, email, phone_number, date_of_birth) FROM stdin;
\.
COPY public.person_information (person_id, first_name, last_name, email, phone_number, date_of_birth) FROM '$$PATH$$/3911.dat';

--
-- Data for Name: price; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.price (price_id, price_amount) FROM stdin;
\.
COPY public.price (price_id, price_amount) FROM '$$PATH$$/3917.dat';

--
-- Data for Name: province; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.province (province_id, province_name, province_code) FROM stdin;
\.
COPY public.province (province_id, province_name, province_code) FROM '$$PATH$$/3913.dat';

--
-- Data for Name: receipt; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.receipt (receipt_id, member_id, payment_method, tax_id, subtotal, tax_amount, total_amount, receipt_date) FROM stdin;
\.
COPY public.receipt (receipt_id, member_id, payment_method, tax_id, subtotal, tax_amount, total_amount, receipt_date) FROM '$$PATH$$/3933.dat';

--
-- Data for Name: receipt_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.receipt_item (receipt_item_id, receipt_id, supplement_id, fitness_class_id, service_id, quantity, price_id, item_subtotal, item_tax_amount, item_total) FROM stdin;
\.
COPY public.receipt_item (receipt_item_id, receipt_id, supplement_id, fitness_class_id, service_id, quantity, price_id, item_subtotal, item_tax_amount, item_total) FROM '$$PATH$$/3951.dat';

--
-- Data for Name: salary; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.salary (salary_id, salary_amount) FROM stdin;
\.
COPY public.salary (salary_id, salary_amount) FROM '$$PATH$$/3919.dat';

--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.services (service_id, service_name, description, duration, price_id, is_taxable) FROM stdin;
\.
COPY public.services (service_id, service_name, description, duration, price_id, is_taxable) FROM '$$PATH$$/3935.dat';

--
-- Data for Name: staff; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.staff (staff_id, person_id, staff_address_id, salary_id, "position") FROM stdin;
\.
COPY public.staff (staff_id, person_id, staff_address_id, salary_id, "position") FROM '$$PATH$$/3927.dat';

--
-- Data for Name: staff_address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.staff_address (staff_address_id, street_name, street_number, city, province_id, postal_code) FROM stdin;
\.
COPY public.staff_address (staff_address_id, street_name, street_number, city, province_id, postal_code) FROM '$$PATH$$/3953.dat';

--
-- Data for Name: supplements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.supplements (supplement_id, brand_id, price_id, supplement_name, stock_amount, reorder_number, min_stock_level, max_stock_level) FROM stdin;
\.
COPY public.supplements (supplement_id, brand_id, price_id, supplement_name, stock_amount, reorder_number, min_stock_level, max_stock_level) FROM '$$PATH$$/3943.dat';

--
-- Data for Name: tax; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tax (tax_id, tax_name, tax_rate, is_active, effective_date, description) FROM stdin;
\.
COPY public.tax (tax_id, tax_name, tax_rate, is_active, effective_date, description) FROM '$$PATH$$/3931.dat';

--
-- Name: address_address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.address_address_id_seq', 552, true);


--
-- Name: brands_brand_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.brands_brand_id_seq', 20, true);


--
-- Name: certifications_certification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.certifications_certification_id_seq', 25, true);


--
-- Name: class_attendance_attendance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.class_attendance_attendance_id_seq', 200, true);


--
-- Name: employee_certifications_employee_certification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employee_certifications_employee_certification_id_seq', 17, true);


--
-- Name: equipment_equipment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.equipment_equipment_id_seq', 54, true);


--
-- Name: equipment_maintenance_maintenance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.equipment_maintenance_maintenance_id_seq', 20, true);


--
-- Name: fitness_class_class_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.fitness_class_class_id_seq', 60, true);


--
-- Name: gym_location_gym_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.gym_location_gym_id_seq', 21, true);


--
-- Name: inventory_log_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inventory_log_log_id_seq', 40, true);


--
-- Name: membership_member_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.membership_member_id_seq', 604, true);


--
-- Name: membership_type_membership_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.membership_type_membership_type_id_seq', 5, true);


--
-- Name: person_information_person_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.person_information_person_id_seq', 200, true);


--
-- Name: price_price_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.price_price_id_seq', 25, true);


--
-- Name: province_province_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.province_province_id_seq', 13, true);


--
-- Name: receipt_item_receipt_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.receipt_item_receipt_item_id_seq', 30, true);


--
-- Name: receipt_receipt_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.receipt_receipt_id_seq', 5, true);


--
-- Name: salary_salary_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.salary_salary_id_seq', 10, true);


--
-- Name: services_service_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.services_service_id_seq', 88, true);


--
-- Name: staff_address_staff_address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.staff_address_staff_address_id_seq', 346, true);


--
-- Name: staff_staff_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.staff_staff_id_seq', 750, true);


--
-- Name: supplements_supplement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.supplements_supplement_id_seq', 964, true);


--
-- Name: tax_tax_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tax_tax_id_seq', 1, true);


--
-- Name: address address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address
    ADD CONSTRAINT address_pkey PRIMARY KEY (address_id);


--
-- Name: brands brands_brand_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.brands
    ADD CONSTRAINT brands_brand_name_key UNIQUE (brand_name);


--
-- Name: brands brands_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.brands
    ADD CONSTRAINT brands_pkey PRIMARY KEY (brand_id);


--
-- Name: certifications certifications_certification_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certifications
    ADD CONSTRAINT certifications_certification_name_key UNIQUE (certification_name);


--
-- Name: certifications certifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certifications
    ADD CONSTRAINT certifications_pkey PRIMARY KEY (certification_id);


--
-- Name: class_attendance class_attendance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class_attendance
    ADD CONSTRAINT class_attendance_pkey PRIMARY KEY (attendance_id);


--
-- Name: employee_certifications employee_certifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_certifications
    ADD CONSTRAINT employee_certifications_pkey PRIMARY KEY (employee_certification_id);


--
-- Name: employee_certifications employee_certifications_staff_id_certification_id_certifica_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_certifications
    ADD CONSTRAINT employee_certifications_staff_id_certification_id_certifica_key UNIQUE (staff_id, certification_id, certificate_number);


--
-- Name: equipment_maintenance equipment_maintenance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipment_maintenance
    ADD CONSTRAINT equipment_maintenance_pkey PRIMARY KEY (maintenance_id);


--
-- Name: equipment equipment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipment
    ADD CONSTRAINT equipment_pkey PRIMARY KEY (equipment_id);


--
-- Name: fitness_class fitness_class_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fitness_class
    ADD CONSTRAINT fitness_class_pkey PRIMARY KEY (class_id);


--
-- Name: gym_location gym_location_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gym_location
    ADD CONSTRAINT gym_location_pkey PRIMARY KEY (gym_id);


--
-- Name: inventory_log inventory_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_log
    ADD CONSTRAINT inventory_log_pkey PRIMARY KEY (log_id);


--
-- Name: membership membership_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.membership
    ADD CONSTRAINT membership_pkey PRIMARY KEY (member_id);


--
-- Name: membership_type membership_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.membership_type
    ADD CONSTRAINT membership_type_pkey PRIMARY KEY (membership_type_id);


--
-- Name: membership_type membership_type_type_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.membership_type
    ADD CONSTRAINT membership_type_type_name_key UNIQUE (type_name);


--
-- Name: person_information person_information_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.person_information
    ADD CONSTRAINT person_information_email_key UNIQUE (email);


--
-- Name: person_information person_information_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.person_information
    ADD CONSTRAINT person_information_pkey PRIMARY KEY (person_id);


--
-- Name: price price_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.price
    ADD CONSTRAINT price_pkey PRIMARY KEY (price_id);


--
-- Name: province province_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.province
    ADD CONSTRAINT province_pkey PRIMARY KEY (province_id);


--
-- Name: province province_province_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.province
    ADD CONSTRAINT province_province_code_key UNIQUE (province_code);


--
-- Name: province province_province_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.province
    ADD CONSTRAINT province_province_name_key UNIQUE (province_name);


--
-- Name: receipt_item receipt_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.receipt_item
    ADD CONSTRAINT receipt_item_pkey PRIMARY KEY (receipt_item_id);


--
-- Name: receipt receipt_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.receipt
    ADD CONSTRAINT receipt_pkey PRIMARY KEY (receipt_id);


--
-- Name: salary salary_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salary
    ADD CONSTRAINT salary_pkey PRIMARY KEY (salary_id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (service_id);


--
-- Name: staff_address staff_address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff_address
    ADD CONSTRAINT staff_address_pkey PRIMARY KEY (staff_address_id);


--
-- Name: staff staff_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_pkey PRIMARY KEY (staff_id);


--
-- Name: supplements supplements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplements
    ADD CONSTRAINT supplements_pkey PRIMARY KEY (supplement_id);


--
-- Name: tax tax_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tax
    ADD CONSTRAINT tax_pkey PRIMARY KEY (tax_id);


--
-- Name: tax tax_tax_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tax
    ADD CONSTRAINT tax_tax_name_key UNIQUE (tax_name);


--
-- Name: idx_address_city; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_address_city ON public.address USING btree (city);


--
-- Name: idx_address_province_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_address_province_id ON public.address USING btree (province_id);


--
-- Name: idx_brand_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_brand_name ON public.brands USING btree (brand_name);


--
-- Name: idx_certification_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_certification_name ON public.certifications USING btree (certification_name);


--
-- Name: idx_certification_organization; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_certification_organization ON public.certifications USING btree (issuing_organization);


--
-- Name: idx_employee_certifications_certification_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employee_certifications_certification_id ON public.employee_certifications USING btree (certification_id);


--
-- Name: idx_employee_certifications_staff_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employee_certifications_staff_id ON public.employee_certifications USING btree (staff_id);


--
-- Name: idx_equipment_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_equipment_name ON public.equipment USING btree (equipment_name);


--
-- Name: idx_inventory_log_log_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inventory_log_log_date ON public.inventory_log USING btree (log_date);


--
-- Name: idx_inventory_log_staff_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inventory_log_staff_id ON public.inventory_log USING btree (staff_id);


--
-- Name: idx_inventory_log_supplement_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inventory_log_supplement_id ON public.inventory_log USING btree (supplement_id);


--
-- Name: idx_membership_address_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_membership_address_id ON public.membership USING btree (address_id);


--
-- Name: idx_membership_person_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_membership_person_id ON public.membership USING btree (person_id);


--
-- Name: idx_membership_price_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_membership_price_id ON public.membership USING btree (price_id);


--
-- Name: idx_membership_type_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_membership_type_id ON public.membership USING btree (membership_type_id);


--
-- Name: idx_membership_type_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_membership_type_name ON public.membership_type USING btree (type_name);


--
-- Name: idx_person_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_person_email ON public.person_information USING btree (email);


--
-- Name: idx_province_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_province_code ON public.province USING btree (province_code);


--
-- Name: idx_province_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_province_name ON public.province USING btree (province_name);


--
-- Name: idx_receipt_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_receipt_date ON public.receipt USING btree (receipt_date);


--
-- Name: idx_receipt_item_fitness_class_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_receipt_item_fitness_class_id ON public.receipt_item USING btree (fitness_class_id);


--
-- Name: idx_receipt_item_receipt_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_receipt_item_receipt_id ON public.receipt_item USING btree (receipt_id);


--
-- Name: idx_receipt_item_service_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_receipt_item_service_id ON public.receipt_item USING btree (service_id);


--
-- Name: idx_receipt_item_supplement_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_receipt_item_supplement_id ON public.receipt_item USING btree (supplement_id);


--
-- Name: idx_receipt_member_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_receipt_member_id ON public.receipt USING btree (member_id);


--
-- Name: idx_services_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_services_name ON public.services USING btree (service_name);


--
-- Name: idx_services_price_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_services_price_id ON public.services USING btree (price_id);


--
-- Name: idx_staff_address_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_staff_address_id ON public.staff USING btree (staff_address_id);


--
-- Name: idx_staff_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_staff_id ON public.fitness_class USING btree (staff_id);


--
-- Name: idx_staff_person_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_staff_person_id ON public.staff USING btree (person_id);


--
-- Name: idx_staff_salary_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_staff_salary_id ON public.staff USING btree (salary_id);


--
-- Name: idx_supplements_brand_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_supplements_brand_id ON public.supplements USING btree (brand_id);


--
-- Name: idx_supplements_price_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_supplements_price_id ON public.supplements USING btree (price_id);


--
-- Name: address address_province_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address
    ADD CONSTRAINT address_province_id_fkey FOREIGN KEY (province_id) REFERENCES public.province(province_id);


--
-- Name: class_attendance class_attendance_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class_attendance
    ADD CONSTRAINT class_attendance_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.fitness_class(class_id);


--
-- Name: class_attendance class_attendance_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class_attendance
    ADD CONSTRAINT class_attendance_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.person_information(person_id);


--
-- Name: employee_certifications employee_certifications_certification_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_certifications
    ADD CONSTRAINT employee_certifications_certification_id_fkey FOREIGN KEY (certification_id) REFERENCES public.certifications(certification_id);


--
-- Name: employee_certifications employee_certifications_staff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_certifications
    ADD CONSTRAINT employee_certifications_staff_id_fkey FOREIGN KEY (staff_id) REFERENCES public.staff(staff_id);


--
-- Name: equipment_maintenance equipment_maintenance_equipment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipment_maintenance
    ADD CONSTRAINT equipment_maintenance_equipment_id_fkey FOREIGN KEY (equipment_id) REFERENCES public.equipment(equipment_id);


--
-- Name: equipment_maintenance equipment_maintenance_performed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipment_maintenance
    ADD CONSTRAINT equipment_maintenance_performed_by_fkey FOREIGN KEY (staff_id) REFERENCES public.staff(staff_id);


--
-- Name: fitness_class fitness_class_price_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fitness_class
    ADD CONSTRAINT fitness_class_price_id_fkey FOREIGN KEY (price_id) REFERENCES public.price(price_id);


--
-- Name: fitness_class fitness_class_staff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fitness_class
    ADD CONSTRAINT fitness_class_staff_id_fkey FOREIGN KEY (staff_id) REFERENCES public.staff(staff_id);


--
-- Name: employee_certifications fk_employee_certifications_certification_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_certifications
    ADD CONSTRAINT fk_employee_certifications_certification_id FOREIGN KEY (certification_id) REFERENCES public.certifications(certification_id);


--
-- Name: employee_certifications fk_employee_certifications_staff_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_certifications
    ADD CONSTRAINT fk_employee_certifications_staff_id FOREIGN KEY (staff_id) REFERENCES public.staff(staff_id);


--
-- Name: inventory_log fk_inventory_log_staff_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_log
    ADD CONSTRAINT fk_inventory_log_staff_id FOREIGN KEY (staff_id) REFERENCES public.staff(staff_id);


--
-- Name: inventory_log fk_inventory_log_supplement_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_log
    ADD CONSTRAINT fk_inventory_log_supplement_id FOREIGN KEY (supplement_id) REFERENCES public.supplements(supplement_id);


--
-- Name: receipt_item fk_receipt_item_receipt_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.receipt_item
    ADD CONSTRAINT fk_receipt_item_receipt_id FOREIGN KEY (receipt_id) REFERENCES public.receipt(receipt_id);


--
-- Name: receipt_item fk_receipt_item_service_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.receipt_item
    ADD CONSTRAINT fk_receipt_item_service_id FOREIGN KEY (service_id) REFERENCES public.services(service_id);


--
-- Name: receipt_item fk_receipt_item_supplement_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.receipt_item
    ADD CONSTRAINT fk_receipt_item_supplement_id FOREIGN KEY (supplement_id) REFERENCES public.supplements(supplement_id);


--
-- Name: receipt fk_receipt_member_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.receipt
    ADD CONSTRAINT fk_receipt_member_id FOREIGN KEY (member_id) REFERENCES public.membership(member_id);


--
-- Name: receipt fk_receipt_tax_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.receipt
    ADD CONSTRAINT fk_receipt_tax_id FOREIGN KEY (tax_id) REFERENCES public.tax(tax_id);


--
-- Name: staff fk_salary_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT fk_salary_id FOREIGN KEY (salary_id) REFERENCES public.salary(salary_id);


--
-- Name: services fk_services_price_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT fk_services_price_id FOREIGN KEY (price_id) REFERENCES public.price(price_id);


--
-- Name: staff fk_staff_address_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT fk_staff_address_id FOREIGN KEY (staff_address_id) REFERENCES public.staff_address(staff_address_id);


--
-- Name: staff fk_staff_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT fk_staff_id FOREIGN KEY (person_id) REFERENCES public.person_information(person_id);


--
-- Name: staff fk_staff_person_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT fk_staff_person_id FOREIGN KEY (person_id) REFERENCES public.person_information(person_id);


--
-- Name: staff fk_staff_salary_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT fk_staff_salary_id FOREIGN KEY (salary_id) REFERENCES public.salary(salary_id);


--
-- Name: supplements fk_supplements_brand_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplements
    ADD CONSTRAINT fk_supplements_brand_id FOREIGN KEY (brand_id) REFERENCES public.brands(brand_id);


--
-- Name: supplements fk_supplements_price_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplements
    ADD CONSTRAINT fk_supplements_price_id FOREIGN KEY (price_id) REFERENCES public.price(price_id);


--
-- Name: gym_location gym_location_address_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gym_location
    ADD CONSTRAINT gym_location_address_id_fkey FOREIGN KEY (address_id) REFERENCES public.address(address_id);


--
-- Name: inventory_log inventory_log_staff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_log
    ADD CONSTRAINT inventory_log_staff_id_fkey FOREIGN KEY (staff_id) REFERENCES public.staff(staff_id);


--
-- Name: inventory_log inventory_log_supplement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_log
    ADD CONSTRAINT inventory_log_supplement_id_fkey FOREIGN KEY (supplement_id) REFERENCES public.supplements(supplement_id);


--
-- Name: membership membership_address_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.membership
    ADD CONSTRAINT membership_address_id_fkey FOREIGN KEY (address_id) REFERENCES public.address(address_id);


--
-- Name: membership membership_membership_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.membership
    ADD CONSTRAINT membership_membership_type_id_fkey FOREIGN KEY (membership_type_id) REFERENCES public.membership_type(membership_type_id);


--
-- Name: membership membership_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.membership
    ADD CONSTRAINT membership_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.person_information(person_id);


--
-- Name: membership membership_price_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.membership
    ADD CONSTRAINT membership_price_id_fkey FOREIGN KEY (price_id) REFERENCES public.price(price_id);


--
-- Name: receipt_item receipt_item_fitness_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.receipt_item
    ADD CONSTRAINT receipt_item_fitness_class_id_fkey FOREIGN KEY (fitness_class_id) REFERENCES public.fitness_class(class_id);


--
-- Name: receipt_item receipt_item_price_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.receipt_item
    ADD CONSTRAINT receipt_item_price_id_fkey FOREIGN KEY (price_id) REFERENCES public.price(price_id);


--
-- Name: receipt_item receipt_item_receipt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.receipt_item
    ADD CONSTRAINT receipt_item_receipt_id_fkey FOREIGN KEY (receipt_id) REFERENCES public.receipt(receipt_id);


--
-- Name: receipt_item receipt_item_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.receipt_item
    ADD CONSTRAINT receipt_item_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(service_id);


--
-- Name: receipt_item receipt_item_supplement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.receipt_item
    ADD CONSTRAINT receipt_item_supplement_id_fkey FOREIGN KEY (supplement_id) REFERENCES public.supplements(supplement_id);


--
-- Name: receipt receipt_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.receipt
    ADD CONSTRAINT receipt_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.membership(member_id);


--
-- Name: receipt receipt_tax_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.receipt
    ADD CONSTRAINT receipt_tax_id_fkey FOREIGN KEY (tax_id) REFERENCES public.tax(tax_id);


--
-- Name: services services_price_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_price_id_fkey FOREIGN KEY (price_id) REFERENCES public.price(price_id);


--
-- Name: staff staff_address_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_address_id_fkey FOREIGN KEY (staff_address_id) REFERENCES public.staff_address(staff_address_id) NOT VALID;


--
-- Name: staff_address staff_address_province_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff_address
    ADD CONSTRAINT staff_address_province_id_fkey FOREIGN KEY (province_id) REFERENCES public.province(province_id);


--
-- Name: staff staff_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.person_information(person_id);


--
-- Name: staff staff_salary_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_salary_id_fkey FOREIGN KEY (salary_id) REFERENCES public.salary(salary_id);


--
-- Name: supplements supplements_brand_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplements
    ADD CONSTRAINT supplements_brand_id_fkey FOREIGN KEY (brand_id) REFERENCES public.brands(brand_id);


--
-- Name: supplements supplements_price_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplements
    ADD CONSTRAINT supplements_price_id_fkey FOREIGN KEY (price_id) REFERENCES public.price(price_id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

